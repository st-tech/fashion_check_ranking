require 'sinatra'
require './app/models/tweet.rb'

get '/' do
  @tweets = Tweet.ranking_top5
  erb :index
end
